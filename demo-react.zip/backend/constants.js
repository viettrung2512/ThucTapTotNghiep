// constants.js

const LIKE_TYPE = {
    POST: "POST",
    COMMENT: "COMMENT",
  };
  
  module.exports = {
    LIKE_TYPE,
  };
  