const UserRole = Object.freeze({
    USER: 'USER',
    ADMIN: 'ADMIN'
  });
  
module.exports = UserRole;
  