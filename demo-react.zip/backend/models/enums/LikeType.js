const LikeType = Object.freeze({
    POST: 'POST',
    COMMENT: 'COMMENT'
  });
  
  module.exports = LikeType;
  