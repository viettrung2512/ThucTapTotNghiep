import SignUp from '../../../components/Auth/SignUp';

const SignUpPage = () => {
  return (
    <div>
      <SignUp />
    </div>
  );
};

export default SignUpPage;
