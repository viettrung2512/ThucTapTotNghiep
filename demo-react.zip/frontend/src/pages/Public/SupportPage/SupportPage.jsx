// eslint-disable-next-line no-unused-vars
import React from "react";
import   Support  from "../../../components/Support/Support";
import  NavBar  from "../../../components/Header/NavBar";

const SupportPage = () => {
  return (
    <div>
      <NavBar />
      <Support />
    </div>
  );
};

export default SupportPage;
