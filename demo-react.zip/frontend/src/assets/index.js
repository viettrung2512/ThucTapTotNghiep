import menu from "./menu.svg";
import close from "./close.svg";
import logo from "./logo.svg";


 
export {
  menu,
  close,
  logo,

};